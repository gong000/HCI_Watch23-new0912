package com.example.samsungsample;

import static android.content.ContentValues.TAG;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.gesture.Gesture;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.provider.SyncStateContract;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;

import com.example.samsungsample.databinding.ActivityMainBinding;
import com.example.samsungsample.dollar.Dollar;
import com.example.samsungsample.dollar.DollarListener;
import com.example.samsungsample.dollar.Point;
import com.google.common.collect.BiMap;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;

import androidx.annotation.NonNull;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Vector;

public class MainActivity extends Activity implements SensorEventListener{


    PaintView paintView;
    //Slider slider;
    boolean mode_one=true;
    boolean mode_two=false;
    boolean mode_three=false;
    boolean mode_four=false;
    private TextView mTextView;
    public boolean watch_active=false;
    private TextView mTextView2;
    private ImageView imgview;
    private String data="";
    private String gyrodata="";
    static String IPAddr="192.168.50.156";
    private ActivityMainBinding binding;
    float[] mRotationMatrix = new float[9];
    float[] orientation = new float[3];
    float[] prev_orientation = {0,0,0};
    private float[] accelerometerReading = new float[3];
    private float[] magnetometerReading = new float[3];
    private GestureDetector myGesture;
    private GestureDetector.OnDoubleTapListener listener;
    Dollar dollar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        mTextView = binding.texting;
        paintView=new PaintView(this);
        dollar=new Dollar(1);
        setContentView(paintView);
        paintView.setBackgroundColor(Color.WHITE);
        dollar.setListener(new DollarListener() {
            @Override
            public void dollarDetected(Dollar dollar) {
            }
        });

        if (checkSelfPermission(Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions( new String[]{Manifest.permission.BODY_SENSORS}, 1);
        } else {
            Log.d(TAG, "ALREADY GRANTED");
        }

        SensorManager mSensorManager=((SensorManager)getSystemService(SENSOR_SERVICE));
        //List<Sensor> sensors=mSensorManager.getSensorList(Sensor.TYPE_ALL);
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_NORMAL);
        //mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR), SensorManager.SENSOR_DELAY_NORMAL,SensorManager.SENSOR_DELAY_UI);
        try {
            Class.forName("dalvik.system.CloseGuard")
                    .getMethod("setEnabled", boolean.class)
                    .invoke(null, true);
        } catch (ReflectiveOperationException e) {
            throw new RuntimeException(e);
        }
        new Thread(() -> {
            while(true)recvData();
        }).start();
    }
    boolean bezel_point=false;
    int mode=1;
    int start_x=0;
    int start_y=0;
    int[] mid_point= {225,225};
    public boolean is_bezel_point(float x, float y){
        double ux=x-mid_point[0];
        double uy=y-mid_point[1];
        double dist=Math.sqrt(Math.pow(ux,2)+Math.pow(uy,2));
        if(dist>170)return true;
        else{
            return false;
        }
    }
    public boolean onTouchEvent(MotionEvent event) {
        if(!watch_active){
            return false;
        }
        dollar.setActive(true);
        setContentView(paintView);
        int x = (int)event.getX();
        int y = (int)event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if(mode_one){
                    paintView.setBackgroundColor(Color.WHITE);
                }else if(mode_two){
                    paintView.setBackgroundColor(Color.YELLOW);
                }else if(mode_three){
                    paintView.setBackgroundColor(Color.GRAY);
                }
                dollar.pointerPressed(x,y);
                if(mode_two){
                    paintView.modetoTwo=true;
                    paintView.setSlider(x,y);
                    Log.d("40??","DOWWWN");
                }else{
                    new Thread(() -> {
                        sendData("np,"+String.valueOf(225)+","+String.valueOf(225),5566);
                    }).start();
                }
                start_x=x;
                start_y=y;
                return true;
            case MotionEvent.ACTION_MOVE:
                //setContentView(paintView);
                if(mode_two){
                    //Log.d("40??","MOVVVE");
                    paintView.setSlider(x,y);
                }else{
                    new Thread(() -> {
                        sendData("p,"+String.valueOf(x)+","+String.valueOf(y),5566);
                    }).start();
                }
                if(is_bezel_point(x,y))bezel_point=true;
                else{
                    bezel_point=false;
                }
                dollar.pointerDragged(x,y);
                return true;
            case MotionEvent.ACTION_UP:
                dollar.pointerReleased(x,y);
                if(mode_one){
                    if(!is_bezel_point(start_x,start_y)){
                        double dist=Math.sqrt(Math.pow((x-start_x),2)+Math.pow((y-start_y),2));
                        if(is_bezel_point(x,y)&&dist>=120){
                            paintView.get_bezel_point(x,y);
                            new Thread(() -> {
                                sendData("stb,"+String.valueOf(paintView.getBezelArea(x,y)),5555);
                            }).start();
                        }
                    }
                }
                else if(mode_two){
                    paintView.setSlider(x,y);
                    //Log.d("40??","UPPPPP");
                }else if(mode_three){
                    //Log.d("INNER","GETINNERPOINT1");
                    if(is_bezel_point(start_x,start_y)){
                        double dist=Math.sqrt(Math.pow((x-start_x),2)+Math.pow((y-start_y),2));
                        //Log.d("INNER","GETINNERPOINT2"+String.valueOf((dist)));
                        if(!is_bezel_point(x,y) && dist>120){
                            paintView.get_inner_point(start_x,start_y);
                            //Log.d("INNER","GETINNERPOINT3");
                            new Thread(() -> {
                                sendData("bts,"+String.valueOf(paintView.getBezelArea(start_x,start_y)),5555);
                            }).start();
                        }
                    }
                }else if(mode_four){
                    if(is_bezel_point(x,y)){
                        double dist=Math.sqrt(Math.pow((x-start_x),2)+Math.pow((y-start_y),2));
                        if(dist<=50){
                            paintView.get_bezel_point(x,y);
                            new Thread(() -> {
                                sendData("btap,"+String.valueOf(paintView.getBezelArea(x,y)),5555);
                            }).start();
                        }
                    }
                }
                    if(dollar.getScore()>0.76f){
                        Log.d("DDD",dollar.getName()+", Acc: "+String.valueOf(dollar.getScore()));
                        if(dollar.getName()=="v"){
                            mode=1;
                            setContentView(paintView);
                            paintView.setBackgroundColor(Color.WHITE);
                            mode_one=true;
                            mode_two=false;
                            paintView.isSlider(false);
                            mode_three=false;
                        }
                        else if(dollar.getName()=="circle CCW"){
                            mode=2;
                            //setContentView(paintView);
                            paintView.setBackgroundColor(Color.YELLOW);
                            mode_one=false;
                            mode_two=true;
                            paintView.modeChange();
                            //paintView.isSlider(true);
                            mode_three=false;
                        }
                        else if(dollar.getName()=="triangle"){
                            mode=3;
                            paintView.setBackgroundColor(Color.GRAY);
                            mode_one=false;
                            paintView.isSlider(false);
                            mode_two=false;
                            mode_three=true;
                        }else if(dollar.getName()=="arrow"){
                            mode_four=true;
                            mode_one=false;
                            paintView.isSlider(false);
                            mode_two=false;
                            mode_three=true;
                        }else if(dollar.getName()=="x"){
                            paintView.prev_x=200;
                            paintView.prev_y=450;
                        }
                    }
                bezel_point=false;
                dollar.setActive(false);
                return true;
        }
        return true;
    }

    public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    System.arraycopy(event.values, 0, accelerometerReading,
                            0, accelerometerReading.length);
            }
            else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                System.arraycopy(event.values, 0, magnetometerReading,
                        0, magnetometerReading.length);

            }
           updateOrientationAngles();
    }
    public void updateOrientationAngles() {
        // Update rotation matrix, which is needed to update orientation angles.
        SensorManager.getRotationMatrix(mRotationMatrix, null,
                accelerometerReading, magnetometerReading);

        // "mRotationMatrix" now has up-to-date information.
        SensorManager.getOrientation(mRotationMatrix, orientation);
        //Z, X ,YMath.abs(prev_orientation[1]-orientation[1])>=10.0f
        if(Math.toDegrees(orientation[1])>(-70.0f) && Math.toDegrees(orientation[1])<0.0f){
            Log.d("ANGLE", String.format("%.2f",Math.toDegrees(orientation[1])));
            watch_active=true;
        }else{
            new Thread(() -> {
                sendData("off"+",",5555);
            }).start();
            paintView.setBackgroundColor(Color.BLACK);
            watch_active=false;
        }
    }
    public static void sendData(String msg, int port){
        try {
            DatagramSocket udpsocket = new DatagramSocket();
            byte[] buffer = msg.getBytes();
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, InetAddress.getByName(IPAddr), port);
            udpsocket.send(packet);
        } catch (SocketException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    public void recvData(){
        try {
            DatagramSocket udpsocket = new DatagramSocket();
            byte[] buffer=new byte[100];
            DatagramPacket packet = new DatagramPacket(buffer,buffer.length,InetAddress.getByName(IPAddr), 5555);
            udpsocket.receive(packet);
            String msg = new String(packet.getData(),0,packet.getLength());
            Log.d("recv",msg);
        } catch (SocketException e) {
            System.out.println(e);
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
package com.example.samsungsample;

import android.util.Log;

public class pixel_pos{
        public pixel_pos(){
//            x_data=new double[10000];
//            y_data=new double[10000];
            //idx=0;
            Log.d("Indexs","IMITTTTTTTTTTT");
        }
        public void pixel_set(double x,double y){
//            x_data[idx]=x;
//            y_data[idx++]=y;
            //Log.d("Indexs",String.valueOf(idx));
        }

}
